NE PAS MODIFIER CE DOSSIER !
IL CONTIENT :
	- ErasBoldITC.ttf
	- Dosis-Light.otf